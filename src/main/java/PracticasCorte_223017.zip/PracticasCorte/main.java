package PracticasCorte;


public class main {
    
    public static void main(String[] args) {
        
        // Ejercicio numero 1
        // EjercicioUno media = new EjercicioUno();
        // media.ingresarCalificaciones();
        // media.media();

        // Ejercicio numero 2
        // EjercicioDos viaje = new EjercicioDos();
        // viaje.ingresarDatos();
        // viaje.precioViaje();

        // Ejercicio numero 3
        // EjercicioTres viaje = new EjercicioTres();
        // viaje.ingresarDatos();
        // viaje.precioTotal();

        // Ejercicio numero 4
        // EjercicioCuatro intercambio = new EjercicioCuatro();
        // intercambio.ingresarDatos();
        // intercambio.intercambioValores();
    }


}
