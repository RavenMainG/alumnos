package Escuela;


public class Main {
    public static void main(String[] args) {

        Universidad gestorUniversidad = new Universidad();

        gestorUniversidad.sistema();

    }
}
